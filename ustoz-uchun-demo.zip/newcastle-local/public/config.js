// API faqat shu serverda ishlaydi. Begona Supabase loyihasiga avtomatik ulanmang.
window.__NEWCASTLE_API_URL__ = "/api/db";
